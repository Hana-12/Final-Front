import React from 'react'

const ProfessionalSelected = () => {
  return (
    <div>ProfessionalSelected</div>
  )
}

export default ProfessionalSelected