import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { GlobalContext } from "../../../context/GlobalContext";
import "./Home.css";
const Home = () => {
  const { state } = useContext(GlobalContext);

  return (
    <div className={state.isDark ? "container-dark" : "container-light"}>
      <h1>Bienvenidos</h1>
    </div>
  );
};

export default Home;
