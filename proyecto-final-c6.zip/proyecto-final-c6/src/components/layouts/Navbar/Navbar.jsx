import React, { useContext } from "react";
import { Link, Outlet } from "react-router-dom";
import { GlobalContext } from "../../../context/GlobalContext";
import Switch from "@mui/material/Switch";
import { ButtonGroup, Button } from "@mui/material";
const Navbar = () => {
  const { state, dispatch } = useContext(GlobalContext);

  const handleChange = () => {
    dispatch({ type: "SWITCH_MODE" });
  };

  return (
    <div>
      <h2>Clinica Odontologica</h2>
      <ButtonGroup
              size="small">
                <Link to="/Home">
                  <Button>Inicio</Button>
                </Link>

                <Link to="/favs">
                  <Button>Favoritos</Button>
                </Link>

                <Link to="/Dentistas">
                  <Button>Odontologos</Button>
                </Link>

                <Link to="/ContactForm">
                  <Button>Contacto</Button>
                </Link>

      </ButtonGroup>
      
      <Switch
        checked={state.isDark}
        onChange={handleChange}
        inputProps={{ "aria-label": "controlled" }}
      />
      <div style={{ minHeight: "80vh" }}>
        <Outlet />
      </div>
    </div>
  );
};

export default Navbar;
