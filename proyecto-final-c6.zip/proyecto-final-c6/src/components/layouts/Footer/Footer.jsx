import React from 'react'
import { Outlet } from 'react-router-dom'

const Footer = () => {
  return (
    
    <div>
        <Outlet />
        <h4>Calle Falsa 123</h4>
        <p>Teléfono: (123) 456-7890</p>
        <p>Correo electrónico: info@example.com</p>
    </div>
  )
}

export default Footer